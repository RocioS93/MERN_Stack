import React from 'react';

const Home = (props) => {
    console.log(props);
    return <h1>Welcome</h1>
};

export default Home;